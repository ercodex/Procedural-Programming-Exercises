// C++ code to check whether a number is even or odd.

#include <iostream>
using namespace std;

int main(){
    int num = 3;
    if(num%2 != 0){
        cout << "odd";
    }
    else{
        cout << "even";
    }
    return 0;
}