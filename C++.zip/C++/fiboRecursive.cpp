// Fibonacci sequence with recursive method.

#include <iostream>
using namespace std;

int fib(int x);

int main() {
   int x , i=0;
   
   cout << "Enter the number of terms of series : ";
   cin >> x;
   cout << "\nFibonnaci Series :";
   
   while(i < x) {
      cout << " " << fib(i) << endl;
      i++;
   }
   
   return 0;
}

int fib(int x){
   
   if((x==1)||(x==0)){
      return x;
   }
   else{
      cout <<"Test: " << fib(x-1) + fib(x-2) << endl;
      return(fib(x-1)+fib(x-2));
   }
}